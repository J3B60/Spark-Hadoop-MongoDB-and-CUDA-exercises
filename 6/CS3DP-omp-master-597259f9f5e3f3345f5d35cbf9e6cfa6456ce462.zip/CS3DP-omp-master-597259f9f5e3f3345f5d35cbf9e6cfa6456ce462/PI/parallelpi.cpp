#include "rdart.h"

using namespace std;

int main(int argc, char *argv[0])
{
  long inCircle=0;
  long n ;
  rdart arrow;
  int id, num_threads;
  seed_seq seeds;

  n = atol(argv[1]);
  cout << n << endl;
  
  id=0;
  num_threads=1;
  vector <unsigned> rseeds(num_threads);
  cout << num_threads << endl;
    
  seeds.generate(rseeds.begin(),rseeds.end());

  high_resolution_clock::time_point t1 = high_resolution_clock::now();
    {

      arrow = rdart(rseeds[id]);
      for(long i=0;i<n;i++){
	inCircle += arrow.throw_dart();
      }
    }
    high_resolution_clock::time_point t2 = high_resolution_clock::now();
    duration<double> time_span = duration_cast<duration<double> >(t2 - t1);
    
  arrow.compute_pi(inCircle, n);
  cout << setprecision(6) << "Ran in " << time_span.count() << " seconds" << endl;
  
  
  return 0;
}
