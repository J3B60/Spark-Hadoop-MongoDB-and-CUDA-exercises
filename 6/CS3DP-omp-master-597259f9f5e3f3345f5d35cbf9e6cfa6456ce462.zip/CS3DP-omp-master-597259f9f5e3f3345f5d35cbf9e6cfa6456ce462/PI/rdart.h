#ifndef RDART_H
#define RDART_H

#include <iostream>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <random>
#include <vector>
#include <iomanip>
#include <ctime>
#include <chrono>
#include <omp.h>

using namespace std;
using namespace std::chrono;

class rdart{
 public:
  rdart();
  rdart(unsigned);
  int throw_dart();
  void compute_pi(long,long);
  int const myid();
 private:
  int id;
  double rmax;
  default_random_engine generator;
  uniform_real_distribution<double> distribution;
};

#endif
