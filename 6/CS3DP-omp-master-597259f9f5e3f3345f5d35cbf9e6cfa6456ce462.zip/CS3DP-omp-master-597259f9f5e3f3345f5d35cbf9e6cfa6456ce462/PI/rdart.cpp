#include "rdart.h"
rdart::rdart(){
  this->id=0;
}

rdart::rdart(unsigned rseed){
  this->id = 0;
  generator.seed(rseed);
  distribution = uniform_real_distribution<double>( (double)0.0,(double)1.0);
}
 
int rdart::throw_dart(){
  double rx, ry;
  double radial_distance;
  rx=(double)distribution(generator);
  ry=(double)distribution(generator);

  radial_distance = sqrt(rx*rx + ry*ry);
  if( radial_distance > double(1.0) ) {
    return 0;
  }
  else{
    return 1;
  }
}

int const rdart::myid(){
  return this->id;
}

void rdart::compute_pi(long in_circle, long ndart){
 double Pi;
 cout << "rdart:in "<< in_circle << " out:" << ndart -in_circle<< endl;
 Pi = 4.0 * (double(in_circle))/double(ndart);
 cout << fixed; 
 cout << setprecision(16) << "rdart:Pi is approx " << Pi << endl;
}

