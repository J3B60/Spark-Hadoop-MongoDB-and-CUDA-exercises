#include <stdio.h>
#include <stdlib.h>

typedef struct CSR_mat{
  int nrow;
  int ncol;
  int nnz;
  int *row_start;
  int *col;
  float *val;
} CSR_mat_t;

int compute_update(float *u, float *v);

int mat_vec(float *u,  CSR_mat_t M, float *v);

void print_vec(float *vec);

void print_mat( CSR_mat_t M);

int build_csr(int nrow, int ncol, int nnz,  CSR_mat_t *M);

int init_csr(int *row_start, int *col, float *val,  CSR_mat_t *M);

int main(){

  int status;
  float v1[9]={0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0 };
  float v2[9]={0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
  float v3[9]={0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };

  int row_start[10]={0,3,7,10,14,19,23,26,30,33};
  int col[33] = {0, 1, 3,
		 0, 1, 2, 4,
		 1, 2, 5,
		 0, 3, 4, 6,
		 1, 3, 4, 5, 7,
		 2, 4, 5, 8,
		 3, 6, 7,
		 4, 6, 7, 8,
		 5, 7, 8};

  float val[33] = {4.0, -1.0,   -1.0,
	           -1.0, 4.0, -1.0,  -1.0,   
 		        -1.0, 4.0,       -1.0,
		   -1.0,           4.0, -1.0,   -1.0, 
		   -1.0,      -1.0, 4.0, -1.0,  -1.0, 
		             -1.0,       -1.0,4.0,        -1.0, 
 		                  -1.0,           4.0,-1.0,
   		                        -1.0,    -1.0, 4.0, -1.0, 		   
		                              -1.0,   -1.0, 4.0};
    

   CSR_mat_t Cmat;
  int i;
  status = build_csr(9,9,33, &Cmat); /* 2d Poisson has 33 non-zeros */

  status = init_csr(row_start,col,val,&Cmat);
  print_mat(Cmat);
  printf("\n");

  /* normalise the matrix values */
  for(i=0;i<Cmat.nnz;i++){
    Cmat.val[i]*=-0.25;
  }



  print_vec(v1);
  printf("\n");
  
  status = mat_vec(v2, Cmat, v1);
  print_vec(v2);
  printf("\n");

  status = mat_vec(v3, Cmat, v2);  
  print_vec(v3);
  printf("\n");
  return 0;
}

void print_vec(float *vec){
  int i,j,ctr;
  ctr=0;

  for(j=0;j<3;j++){
    for(i=0;i<3;i++){      
      printf(" %f ",vec[ctr]);
      ctr++;
    }
    printf("\n");
  }
}

int mat_vec(float *v,  CSR_mat_t M, float *u){
  int i,j;
  for(i=0;i<M.nrow;i++){
      for(j=M.row_start[i]; j<M.row_start[i+1]; j++){
	v[i]+= M.val[j] * u[ M.col[j] ] ;
      }
    }
  return 0;
}

int build_csr(int nrow, int ncol, int nnz,  CSR_mat_t *M){
  M->nrow=nrow;
  M->ncol=ncol;
  M->nnz=nnz;

  M->row_start = (int *) malloc(M->nrow+1*sizeof(int));
  M->col = (int *) malloc(M->nnz*sizeof(int));
  M->val = (float *) malloc(M->nnz*sizeof(float));
  return 0;
}

int init_csr(int *row_start, int *col, float *val,  CSR_mat_t *M){
  M->row_start=row_start;
  M->col=col;
  M->val=val;
  
  return 0;
}

void print_mat( CSR_mat_t M){
  int i, j, nz;
  nz=0;
  for(i=0;i<M.nrow;i++){
    for(j=0;j<M.ncol;j++){
      if(nz<M.row_start[i+1] ){
	if( M.col[nz] == j ){
	  printf(" %2.0f ", M.val[nz]);
	  nz++;
	}
	else{
	  printf(" %2.0f ",0.0);
	}
      }
      else{
	printf(" %2.0f ",0.0);
      }
    }
    printf("\n");
  }
}
